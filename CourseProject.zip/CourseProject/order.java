import java.util.*; // import java utilities package
import calculate.*; // import calculate package

interface menu { // holds both options menu and the food menu
	public static String optionsMenu = "\nWelcome to Java Shop!\n" + // main menu, prompts user to input a character
								"A - Add Item\n" +
								"R - Remove Item\n" +
								"T - View Total\n" +
								"Q - Quit\n\n";
	
	public static String foodMenu = "\n*** MENU ***\n" + // food menu, displays items and item cost
							 "ADD ITEMS TO CART\n" + 
							 "1 - Burger $2.50\n" +
							 "2 - Fries $2.00\n" +
							 "3 - Soda $1.00\n" +
							 "4 - Shake $3.00\n\n";
}

interface receipt extends menu { // receipt class to view customer order
		public static List<String> customerOrder = new ArrayList<String>(); // declaring an ArrayList to store customer orders in order to view
}

class order implements receipt { 
	public static void printOrder() { // print function allows user to view their order for removal
			for (int i = 0; i < customerOrder.size(); i++)
			{
				System.out.println(customerOrder.get(i)); 
			}
		}
	public static void main(String args[])
		throws java.io.IOException {
		Scanner scan = new Scanner(System.in); // reads user input
		String selection;	// selection variable contains user input
		calcTotal calculator = new calcTotal(); // calculator object from calculate package allows us to access member functions 
		do
		{
			System.out.print(optionsMenu); // prints out options menu
			
			System.out.print("Make a selection: "); // prompts user to make a selection by typing in name of the item
			selection = scan.nextLine().toUpperCase(); // changes user input to uppercase  for less code
			
			if (selection.equals("A")) // if user inputs an a/A program will prompt user to add an item to their cart
			{
				System.out.print(foodMenu); // order class prints out menu implemented from menu interface
				System.out.print("Enter Item Number: "); // prompts user to enter an item number to add to total
				String foodChoice; // user input
				foodChoice = scan.nextLine(); // scanner reads user input
				calculator.addItem(foodChoice); // new calculator object of type calcToal allows use of member functions within calcToal
				
				switch (foodChoice) // switch statement for all of the various menu options, adds item to cart, and adds item cost to total
				{
					case "1":
					customerOrder.add("burger");
					System.out.println("\nBurger added to cart");
					break;
					
					case "2":
					customerOrder.add("fries");
					System.out.println("\nFries added to cart.");
					break;
					
					case "3":
					customerOrder.add("soda");
					System.out.println("\nSoda added to cart.");
					break;
					
					case "4":
					customerOrder.add("shake");
					System.out.println("\nShake added to cart.");
					break;
					
					default:
					break;
				}
			}
			
			else if (selection.equals("R")) // remove item function, user types out item they want removed from their cart
			{
				String remove_items; // item to be removed
				System.out.println("Which item to remove?");
				printOrder(); // prints out current customer order
				System.out.print("Type item name: "); 
				remove_items = scan.nextLine();
				calculator.removeItem(remove_items);
				
				switch(remove_items) // various cases for removal 
				{
					case "burger":
					customerOrder.remove("burger");
					System.out.println("\nBurger removed from cart.");
					break;
					
					case "fries":
					customerOrder.remove("fries");
					System.out.println("\nFries removed from cart.");
					break;
					
					case "soda":
					customerOrder.remove("soda");
					System.out.println("\nSoda removed from cart.");
					break;
					
					case "shake":
					customerOrder.remove("shake");
					System.out.println("\nShake removed from cart.");
					break;
					
					default:
					break;
				}
				
			}
			
			else if (selection.equals("T")) // prints out the total customer cart
			{
				System.out.println("\nTotal: $" + calculator.viewTotal() + "\n");
			}
	
		
			
		} while (!selection.equals("Q")); // menu continues to display until the customer enters a Q
			
			System.out.println("\nThank you for choosing Java Shop!"); // good
	}
			
		
}
