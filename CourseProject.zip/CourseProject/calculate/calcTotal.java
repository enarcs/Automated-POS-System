package calculate;

public class calcTotal { // addItem, removeItem, and viewTotal functions
	double total;
	public void addItem (String selection) { // adds dollar amount to total once item is added
		if (selection.equals("1")) {
			total += 2.50;
		}
		
		else if (selection.equals("2")) {
			total += 2.00;
		}
		
		else if (selection.equals("3")) {
			total += 1.00;
		}
		
		else if (selection.equals("4")) {
			total += 3.00;
		}
		
		else 
			System.out.print("Invalid selection");
	}
	
	public void removeItem (String selection) { // subtracts dollar amount once item is removed
		if (selection.equals("burger")) {
			total -= 2.50;
		}
		
		else if (selection.equals("fries")) {
			total -= 2.00;
		}
		
		else if (selection.equals("soda")) {
			total -= 1.00;
		}
		
		else if (selection.equals("shake")) {
			total -= 3.00;
		}
		
		else 
			System.out.print("Invalid selection"); 
	}
	
	public String viewTotal() { // function reformats the double into a string and returns it formatted to the 2nd decimal place
		String numberAsString = String.format ("%.2f", total);
        return numberAsString;
	}
}
